/*
 * [Yi Zhao]
 * [Class INFO5101]
 * [Assignment3]
 * [Section8]
 * [NUID:002103352]
 * 
 * This is main program.
 */
public class WeightedGrade_main {

	public static void main(String[] args) {
	try {
		min_window window = new min_window();
		window.open();
	} catch (Exception e) {
		e.printStackTrace();
	}
}

}
