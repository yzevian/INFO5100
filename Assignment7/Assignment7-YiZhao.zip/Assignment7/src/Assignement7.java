/*
 * [Yi Zhao]
 * [Class INFO5101]
 * [Assignment3]
 * [Section8]
 * [NUID:002103352]
 * 
 *
 * This is a main file.
 */

public class Assignement7 {
	public static void main(String[] args) {
		try {
			minWindow window = new minWindow();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
